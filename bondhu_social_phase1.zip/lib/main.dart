import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:image_picker/image_picker.dart';

import 'firebase_options.dart';
import 'services/auth_service.dart';
import 'services/data_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const BondhuApp());
}

final authService = AuthService();
final dataService = DataService();

class BondhuApp extends StatelessWidget {
  const BondhuApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Bondhu Social',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF3D7A4A)),
        useMaterial3: true,
      ),
      home: StreamBuilder<User?>(
        stream: authService.authState,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Scaffold(
              body: Center(child: CircularProgressIndicator()),
            );
          }
          return snapshot.data == null ? const LoginPage() : const MainPage();
        },
      ),
    );
  }
}

String firebaseMessage(Object error) {
  if (error is FirebaseAuthException) {
    switch (error.code) {
      case 'email-already-in-use':
        return 'এই ইমেইল দিয়ে আগে থেকেই অ্যাকাউন্ট আছে।';
      case 'invalid-email':
        return 'ইমেইল ঠিক নয়।';
      case 'weak-password':
        return 'পাসওয়ার্ড কমপক্ষে 6 অক্ষরের দিন।';
      case 'invalid-credential':
      case 'wrong-password':
      case 'user-not-found':
        return 'ইমেইল বা পাসওয়ার্ড সঠিক নয়।';
      case 'invalid-verification-code':
        return 'OTP সঠিক নয়।';
      case 'too-many-requests':
        return 'অনেকবার চেষ্টা হয়েছে। কিছুক্ষণ পরে আবার চেষ্টা করুন।';
      default:
        return error.message ?? 'Authentication error হয়েছে।';
    }
  }
  return error.toString();
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool loading = false;

  Future<void> login() async {
    if (email.text.trim().isEmpty || password.text.isEmpty) {
      _show('ইমেইল ও পাসওয়ার্ড দিন।');
      return;
    }
    setState(() => loading = true);
    try {
      await authService.login(
        email: email.text,
        password: password.text,
      );
    } catch (e) {
      _show(firebaseMessage(e));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> googleLogin() async {
    setState(() => loading = true);
    try {
      await authService.googleLogin();
    } catch (e) {
      _show(firebaseMessage(e));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  void _show(String text) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 480),
              child: Column(
                children: [
                  const CircleAvatar(
                    radius: 42,
                    child: Icon(Icons.people_alt_rounded, size: 45),
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'Bondhu Social',
                    style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 6),
                  const Text('বন্ধুদের সাথে যুক্ত থাকুন'),
                  const SizedBox(height: 30),
                  TextField(
                    controller: email,
                    keyboardType: TextInputType.emailAddress,
                    decoration: const InputDecoration(
                      labelText: 'ইমেইল',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.email_outlined),
                    ),
                  ),
                  const SizedBox(height: 14),
                  TextField(
                    controller: password,
                    obscureText: true,
                    decoration: const InputDecoration(
                      labelText: 'পাসওয়ার্ড',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.lock_outline),
                    ),
                  ),
                  const SizedBox(height: 18),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: loading ? null : login,
                      child: Text(loading ? 'অপেক্ষা করুন...' : 'লগইন'),
                    ),
                  ),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    onPressed: loading ? null : googleLogin,
                    icon: const Icon(Icons.g_mobiledata, size: 30),
                    label: const Text('Google দিয়ে চালিয়ে যান'),
                  ),
                  TextButton(
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const SignupPage()),
                    ),
                    child: const Text('নতুন অ্যাকাউন্ট খুলুন'),
                  ),
                  TextButton(
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const PhoneLoginPage()),
                    ),
                    child: const Text('ফোন নম্বর দিয়ে লগইন / রেজিস্টার'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class SignupPage extends StatefulWidget {
  const SignupPage({super.key});
  @override
  State<SignupPage> createState() => _SignupPageState();
}

class _SignupPageState extends State<SignupPage> {
  final name = TextEditingController();
  final email = TextEditingController();
  final password = TextEditingController();
  bool loading = false;

  Future<void> createAccount() async {
    if (name.text.trim().isEmpty ||
        email.text.trim().isEmpty ||
        password.text.length < 6) {
      _show('নাম, সঠিক ইমেইল এবং কমপক্ষে 6 অক্ষরের পাসওয়ার্ড দিন।');
      return;
    }
    setState(() => loading = true);
    try {
      await authService.signUp(
        name: name.text,
        email: email.text,
        password: password.text,
      );
      if (mounted) Navigator.pop(context);
    } catch (e) {
      _show(firebaseMessage(e));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  void _show(String text) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('নতুন অ্যাকাউন্ট')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          TextField(
            controller: name,
            decoration: const InputDecoration(
              labelText: 'নাম',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 14),
          TextField(
            controller: email,
            keyboardType: TextInputType.emailAddress,
            decoration: const InputDecoration(
              labelText: 'ইমেইল',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 14),
          TextField(
            controller: password,
            obscureText: true,
            decoration: const InputDecoration(
              labelText: 'পাসওয়ার্ড',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 20),
          FilledButton(
            onPressed: loading ? null : createAccount,
            child: Text(loading ? 'তৈরি হচ্ছে...' : 'অ্যাকাউন্ট তৈরি করুন'),
          ),
        ],
      ),
    );
  }
}

class PhoneLoginPage extends StatefulWidget {
  const PhoneLoginPage({super.key});
  @override
  State<PhoneLoginPage> createState() => _PhoneLoginPageState();
}

class _PhoneLoginPageState extends State<PhoneLoginPage> {
  final phone = TextEditingController(text: '+880');
  final otp = TextEditingController();
  String? verificationId;
  bool loading = false;

  Future<void> sendOtp() async {
    if (phone.text.trim().length < 10) {
      _show('সঠিক ফোন নম্বর দিন। উদাহরণ: +8801XXXXXXXXX');
      return;
    }
    setState(() => loading = true);
    try {
      await authService.sendPhoneCode(
        phoneNumber: phone.text,
        onCodeSent: (id) {
          if (mounted) {
            setState(() {
              verificationId = id;
              loading = false;
            });
            _show('OTP পাঠানো হয়েছে।');
          }
        },
        onAutoVerified: (credential) async {
          await authService.signInWithPhoneCredential(credential);
        },
        onError: (error) {
          if (mounted) {
            setState(() => loading = false);
            _show(firebaseMessage(error));
          }
        },
      );
    } catch (e) {
      if (mounted) setState(() => loading = false);
      _show(firebaseMessage(e));
    }
  }

  Future<void> verifyOtp() async {
    final id = verificationId;
    if (id == null || otp.text.trim().length < 4) {
      _show('OTP দিন।');
      return;
    }
    setState(() => loading = true);
    try {
      await authService.verifyPhoneCode(
        verificationId: id,
        smsCode: otp.text,
      );
    } catch (e) {
      _show(firebaseMessage(e));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  void _show(String text) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ফোন নম্বর')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          TextField(
            controller: phone,
            keyboardType: TextInputType.phone,
            decoration: const InputDecoration(
              labelText: 'ফোন নম্বর',
              hintText: '+8801XXXXXXXXX',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 14),
          FilledButton(
            onPressed: loading ? null : sendOtp,
            child: const Text('OTP পাঠান'),
          ),
          if (verificationId != null) ...[
            const SizedBox(height: 22),
            TextField(
              controller: otp,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'OTP',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 14),
            FilledButton(
              onPressed: loading ? null : verifyOtp,
              child: const Text('OTP যাচাই করুন'),
            ),
          ],
        ],
      ),
    );
  }
}

class MainPage extends StatefulWidget {
  const MainPage({super.key});
  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      const HomePage(),
      const ProfilePage(),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Bondhu',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        actions: [
          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.search),
          ),
          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.notifications_none),
          ),
        ],
      ),
      body: pages[index],
      floatingActionButton: index == 0
          ? FloatingActionButton(
              onPressed: () => showModalBottomSheet(
                context: context,
                isScrollControlled: true,
                builder: (_) => const CreatePostSheet(),
              ),
              child: const Icon(Icons.add),
            )
          : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home),
            label: 'Home',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline),
            selectedIcon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: dataService.postsStream(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Text(
                'Feed load করতে সমস্যা হয়েছে.\nFirestore চালু আছে কিনা দেখুন.\n\n${snapshot.error}',
                textAlign: TextAlign.center,
              ),
            ),
          );
        }
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final docs = snapshot.data!.docs;
        if (docs.isEmpty) {
          return const Center(
            child: Text('এখনও কোনো পোস্ট নেই। নিচের + চাপ দিয়ে প্রথম পোস্ট করুন।'),
          );
        }

        return ListView.builder(
          padding: const EdgeInsets.only(bottom: 90),
          itemCount: docs.length,
          itemBuilder: (context, index) {
            return PostCard(doc: docs[index]);
          },
        );
      },
    );
  }
}

class PostCard extends StatelessWidget {
  const PostCard({super.key, required this.doc});
  final QueryDocumentSnapshot<Map<String, dynamic>> doc;

  @override
  Widget build(BuildContext context) {
    final data = doc.data();
    final likes = List<dynamic>.from(data['likes'] ?? const []);
    final uid = authService.currentUser?.uid;
    final liked = uid != null && likes.contains(uid);

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      elevation: 0,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const CircleAvatar(child: Icon(Icons.person)),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    data['name'] ?? 'Bondhu User',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
            if ((data['text'] ?? '').toString().isNotEmpty) ...[
              const SizedBox(height: 10),
              Text(data['text'].toString()),
            ],
            if ((data['imageUrl'] ?? '').toString().isNotEmpty) ...[
              const SizedBox(height: 10),
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.network(
                  data['imageUrl'].toString(),
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
            ],
            const SizedBox(height: 6),
            Row(
              children: [
                Text('${likes.length} Like'),
                const Spacer(),
                TextButton.icon(
                  onPressed: uid == null
                      ? null
                      : () => dataService.toggleLike(
                            postId: doc.id,
                            uid: uid,
                            likes: likes,
                          ),
                  icon: Icon(
                    liked ? Icons.favorite : Icons.favorite_border,
                  ),
                  label: const Text('Like'),
                ),
                TextButton.icon(
                  onPressed: () {},
                  icon: const Icon(Icons.comment_outlined),
                  label: const Text('Comment'),
                ),
                IconButton(
                  onPressed: () {},
                  icon: const Icon(Icons.share_outlined),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class CreatePostSheet extends StatefulWidget {
  const CreatePostSheet({super.key});
  @override
  State<CreatePostSheet> createState() => _CreatePostSheetState();
}

class _CreatePostSheetState extends State<CreatePostSheet> {
  final controller = TextEditingController();
  File? image;
  bool loading = false;

  Future<void> pickImage() async {
    final result = await ImagePicker().pickImage(
      source: ImageSource.gallery,
      imageQuality: 80,
    );
    if (result != null) {
      setState(() => image = File(result.path));
    }
  }

  Future<void> publish() async {
    final user = authService.currentUser;
    if (user == null) return;
    if (controller.text.trim().isEmpty && image == null) return;

    setState(() => loading = true);
    try {
      await dataService.createPost(
        uid: user.uid,
        name: user.displayName ?? 'Bondhu User',
        text: controller.text,
        image: image,
      );
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Post তৈরি হয়নি: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 16,
        right: 16,
        top: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Create Post',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 15),
            TextField(
              controller: controller,
              maxLines: 5,
              decoration: const InputDecoration(
                hintText: 'আপনার মনে কী আছে?',
                border: OutlineInputBorder(),
              ),
            ),
            if (image != null) ...[
              const SizedBox(height: 10),
              ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Image.file(
                  image!,
                  height: 180,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
            ],
            Row(
              children: [
                IconButton(
                  onPressed: loading ? null : pickImage,
                  icon: const Icon(Icons.photo, color: Colors.green),
                ),
                const Text('Photo'),
                const Spacer(),
                FilledButton.icon(
                  onPressed: loading ? null : publish,
                  icon: const Icon(Icons.send),
                  label: Text(loading ? 'Uploading...' : 'Post'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});
  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final name = TextEditingController();
  final bio = TextEditingController();
  bool loading = false;

  Future<void> loadProfile() async {
    final uid = authService.currentUser?.uid;
    if (uid == null) return;
    final doc = await dataService.db.collection('users').doc(uid).get();
    final data = doc.data();
    if (data != null) {
      name.text = (data['name'] ?? '').toString();
      bio.text = (data['bio'] ?? '').toString();
    }
  }

  @override
  void initState() {
    super.initState();
    loadProfile();
  }

  Future<void> save() async {
    final uid = authService.currentUser?.uid;
    if (uid == null) return;
    setState(() => loading = true);
    try {
      await dataService.saveProfile(
        uid: uid,
        name: name.text,
        bio: bio.text,
      );
      await authService.currentUser!.updateDisplayName(name.text.trim());
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Profile saved')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Profile save হয়নি: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = authService.currentUser;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const CircleAvatar(
          radius: 52,
          child: Icon(Icons.person, size: 55),
        ),
        const SizedBox(height: 12),
        Text(
          user?.email ?? '',
          textAlign: TextAlign.center,
          style: Theme.of(context).textTheme.bodyMedium,
        ),
        const SizedBox(height: 20),
        TextField(
          controller: name,
          decoration: const InputDecoration(
            labelText: 'নাম',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 14),
        TextField(
          controller: bio,
          maxLines: 3,
          decoration: const InputDecoration(
            labelText: 'Bio',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 14),
        FilledButton(
          onPressed: loading ? null : save,
          child: Text(loading ? 'Saving...' : 'Profile Save'),
        ),
        const SizedBox(height: 10),
        OutlinedButton.icon(
          onPressed: () => authService.logout(),
          icon: const Icon(Icons.logout),
          label: const Text('Logout'),
        ),
      ],
    );
  }
}
