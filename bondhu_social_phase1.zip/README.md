# Bondhu Social - Phase 1

This starter is based on the uploaded Bondhu Social MVP.

Included:
- Firebase Email/Password sign up and login
- Google Sign-In
- Phone + OTP authentication
- Firestore user profiles
- Firestore live feed
- Text/photo posts
- Firebase Storage image upload
- Like toggle
- Basic profile editing and logout

## Firebase setup

1. Firebase project: `bondhu-social-c01e2`
2. Android package: `com.bondhu.social`
3. Put your `google-services.json` at:
   `android/app/google-services.json`
4. Enable in Firebase Authentication:
   - Email/Password
   - Google
   - Phone
5. Create Firestore Database.
6. Enable Storage.
7. For Google/Phone authentication on Android, add your SHA-1/SHA-256 fingerprints in Firebase Project Settings.
8. In a full Flutter checkout, run:
   `flutterfire configure`
   to generate the platform-specific `firebase_options.dart`.

## Important

The uploaded source ZIP contained only README.md, pubspec.yaml and lib/main.dart, so it did not contain generated Android/iOS platform folders. In a Flutter environment, run `flutter create .` before building the Android app if those folders are missing.

Next phases:
Friends -> Messenger -> Stories -> Reels -> Groups -> Pages -> Notifications -> Admin Panel.
